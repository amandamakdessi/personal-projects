/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package snakegame;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class GameBoard extends JPanel implements ActionListener {

    private static final long serialVersionUID = 1L;
    static final int BOARD_WIDTH = 600;
    static final int BOARD_HEIGHT = 600;
    static final int UNIT_SIZE = 20;
    static final int TOTAL_UNITS = (BOARD_WIDTH * BOARD_HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    final int xCoordinates[] = new int[TOTAL_UNITS];
    final int yCoordinates[] = new int[TOTAL_UNITS];
    int snakeSize = 6;
    int applesEaten;
    int appleX;
    int appleY;
    char currentDirection = 'R';
    boolean isRunning = false;
    Timer gameTimer;
    Random random;

    GameBoard() {
        random = new Random();
        this.setPreferredSize(new Dimension(BOARD_WIDTH, BOARD_HEIGHT));
        this.setBackground(new Color(220, 220, 255));
        this.setFocusable(true);
        this.addKeyListener(new KeyInputHandler());
        startGame();
    }

    public void startGame() {
        placeApple();
        isRunning = true;
        gameTimer = new Timer(75, this);
        gameTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGame(g);
    }

    private void drawGame(Graphics g) {
        if (isRunning) {
            drawApple(g);
            drawSnake(g);
            drawScore(g);
        } else {
            showGameOver(g);
        }
    }

    private void drawApple(Graphics g) {
        g.setColor(new Color(255, 255, 153));
        g.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);
    }

    private void drawSnake(Graphics g) {
        for (int i = 0; i < snakeSize; i++) {
            if (i == 0) {
                g.setColor(new Color(180, 100, 200));
            } else {
                g.setColor(new Color(170, 120, 210));
            }
            g.fillRect(xCoordinates[i], yCoordinates[i], UNIT_SIZE, UNIT_SIZE);
        }
    }

    private void drawScore(Graphics g) {
        g.setColor(Color.black);
        g.setFont(new Font("Ink Free", Font.BOLD, 30));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesEaten, (BOARD_WIDTH - metrics.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());
    }

    private void placeApple() {
        appleX = random.nextInt((int) (BOARD_WIDTH / UNIT_SIZE)) * UNIT_SIZE;
        appleY = random.nextInt((int) (BOARD_HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
    }

    private void moveSnake() {
        for (int i = snakeSize; i > 0; i--) {
            xCoordinates[i] = xCoordinates[i - 1];
            yCoordinates[i] = yCoordinates[i - 1];
        }

        switch (currentDirection) {
            case 'U':
                yCoordinates[0] = yCoordinates[0] - UNIT_SIZE;
                break;
            case 'D':
                yCoordinates[0] = yCoordinates[0] + UNIT_SIZE;
                break;
            case 'L':
                xCoordinates[0] = xCoordinates[0] - UNIT_SIZE;
                break;
            case 'R':
                xCoordinates[0] = xCoordinates[0] + UNIT_SIZE;
                break;
        }
    }

    private void checkAppleCollision() {
        if ((xCoordinates[0] == appleX) && (yCoordinates[0] == appleY)) {
            snakeSize++;
            applesEaten++;
            placeApple();
        }
    }

    private void checkSelfCollision() {
        for (int i = snakeSize; i > 0; i--) {
            if ((xCoordinates[0] == xCoordinates[i]) && (yCoordinates[0] == yCoordinates[i])) {
                isRunning = false;
                break;
            }
        }

        if (xCoordinates[0] < 0 || xCoordinates[0] >= BOARD_WIDTH || yCoordinates[0] < 0 || yCoordinates[0] >= BOARD_HEIGHT) {
            isRunning = false;
        }

        if (!isRunning) {
            gameTimer.stop();
        }
    }

    private void showGameOver(Graphics g) {
        g.setColor(new Color(180, 100, 200));
        g.setFont(new Font("Ink Free", Font.BOLD, 75));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString("Game Over", (BOARD_WIDTH - metrics.stringWidth("Game Over")) / 2, BOARD_HEIGHT / 2);

        g.setColor(Color.black);
        g.setFont(new Font("Ink Free", Font.BOLD, 30));
        metrics = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesEaten, (BOARD_WIDTH - metrics.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (isRunning) {
            moveSnake();
            checkAppleCollision();
            checkSelfCollision();
        }
        repaint();
    }

    private class KeyInputHandler extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    if (currentDirection != 'R') {
                        currentDirection = 'L';
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    if (currentDirection != 'L') {
                        currentDirection = 'R';
                    }
                    break;
                case KeyEvent.VK_UP:
                    if (currentDirection != 'D') {
                        currentDirection = 'U';
                    }
                    break;
                case KeyEvent.VK_DOWN:
                    if (currentDirection != 'U') {
                        currentDirection = 'D';
                    }
                    break;
            }
        }
    }
}