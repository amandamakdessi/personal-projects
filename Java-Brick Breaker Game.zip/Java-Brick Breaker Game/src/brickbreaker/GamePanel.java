/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package brickbreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements KeyListener, ActionListener {
    private boolean isPlaying = false;
    private int score = 0;
    private int totalBricks = 21;
    private Timer timer;
    private int delay = 8;
    private int playerX = 310;
    private int ballPosX = 120;
    private int ballPosY = 320;
    private int ballDirX = -1;
    private int ballDirY = -2;
    private BrickMap brickMap;

    public GamePanel() {
        brickMap = new BrickMap(3, 7);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        timer = new Timer(delay, this);
        timer.start();
    }

    public void paint(Graphics g) {
    
    g.setColor(new Color(255, 229, 204)); 
    g.fillRect(1, 1, 692, 592);

    
    brickMap.draw((Graphics2D) g);

    
    g.setColor(new Color(110, 232, 250)); 
    g.fillRect(0, 0, 3, 592);
    g.fillRect(0, 0, 692, 3);
    g.fillRect(691, 0, 3, 592);

    
    g.setColor(new Color(0, 0, 204)); 
    g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
    String scoreText = "Score: " + score;
    g.drawString(scoreText, 692 / 2 - g.getFontMetrics().stringWidth(scoreText) / 2, 30);

    
    g.setColor(new Color(0, 0, 204)); 
    g.fillRect(playerX, 550, 100, 8);

   
    g.setColor(new Color(173, 216, 230)); 
    g.fillOval(ballPosX, ballPosY, 20, 20);

    
    if (totalBricks <= 0) {
        isPlaying = false;
        ballDirX = 0;
        ballDirY = 0;
        g.setColor(new Color(0, 0, 204));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 35));
        String winText = "You Won!";
        g.drawString(winText, 692 / 2 - g.getFontMetrics().stringWidth(winText) / 2, 300);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        String restartText = "Press Enter to Restart";
        g.drawString(restartText, 692 / 2 - g.getFontMetrics().stringWidth(restartText) / 2, 400);
    }

   
    if (ballPosY > 570) {
        isPlaying = false;
        ballDirX = 0;
        ballDirY = 0;
        g.setColor(new Color(0, 0, 204));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 35));
        String gameOverText = "Game Over! Your score: " + score;
        g.drawString(gameOverText, 692 / 2 - g.getFontMetrics().stringWidth(gameOverText) / 2, 300);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        String restartText = "Press Enter to Restart";
        g.drawString(restartText, 692 / 2 - g.getFontMetrics().stringWidth(restartText) / 2, 400);
    }

    g.dispose();
}

    @Override
    public void actionPerformed(ActionEvent e) {
        timer.start();
        if (isPlaying) {
            if (new Rectangle(ballPosX, ballPosY, 20, 20).intersects(new Rectangle(playerX, 550, 100, 8))) {
                ballDirY = -ballDirY;
            }

            A: for (int i = 0; i < brickMap.map.length; i++) {
                for (int j = 0; j < brickMap.map[0].length; j++) {
                    if (brickMap.map[i][j] > 0) {
                        int brickX = j * brickMap.brickWidth + 80;
                        int brickY = i * brickMap.brickHeight + 50;
                        int brickWidth = brickMap.brickWidth;
                        int brickHeight = brickMap.brickHeight;

                        Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
                        Rectangle ballRect = new Rectangle(ballPosX, ballPosY, 20, 20);
                        Rectangle brickRect = rect;

                        if (ballRect.intersects(brickRect)) {
                            brickMap.setBrickValue(0, i, j);
                            totalBricks--;
                            score += 5;

                            if (ballPosX + 19 <= brickRect.x || ballPosX + 1 >= brickRect.x + brickRect.width) {
                                ballDirX = -ballDirX;
                            } else {
                                ballDirY = -ballDirY;
                            }
                            break A;
                        }
                    }
                }
            }

            ballPosX += ballDirX;
            ballPosY += ballDirY;
            if (ballPosX < 0) {
                ballDirX = -ballDirX;
            }
            if (ballPosY < 0) {
                ballDirY = -ballDirY;
            }
            if (ballPosX > 670) {
                ballDirX = -ballDirX;
            }
        }
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            if (playerX >= 600) {
                playerX = 600;
            } else {
                moveRight();
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            if (playerX <= 10) {
                playerX = 10;
            } else {
                moveLeft();
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!isPlaying) {
                isPlaying = true;
                ballPosX = 120;
                ballPosY = 320;
                ballDirX = -1;
                ballDirY = -2;
                playerX = 310;
                score = 0;
                totalBricks = 21;
                brickMap = new BrickMap(3, 7);
                repaint();
            }
        }
    }

    public void moveRight() {
        isPlaying = true;
        playerX += 20;
    }

    public void moveLeft() {
        isPlaying = true;
        playerX -= 20;
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}